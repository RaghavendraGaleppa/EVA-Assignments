.. _deprecations:


Feature and API deprecation cycle
=================================

This document will list any features or APIs of django-registration
which are deprecated and scheduled to be removed in future releases.

As of |release|, no features or APIs are currently deprecated.